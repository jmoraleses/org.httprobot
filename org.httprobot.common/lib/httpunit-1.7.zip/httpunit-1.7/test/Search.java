import com.meterware.httpunit.Base64;

/**
 * Created by IntelliJ IDEA.
 * User: russgold
 * Date: Dec 24, 2007
 * Time: 3:21:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class Search {

    public static void main( String args[] ) {
        System.out.println( Base64.decode( "eyAnOicgPT4gJycsICcgJyA9PiAnLScsICdzXG4nID0+ICdzLmNvbVxuJyB9" ) );
    }

}
